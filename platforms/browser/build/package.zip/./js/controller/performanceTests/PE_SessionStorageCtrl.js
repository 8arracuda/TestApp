sdApp.controller('PE_SessionStorageCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PE';

});