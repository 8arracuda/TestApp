sdApp.controller('PL_LocalStorageCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PL';

    $scope.localStorage = localStorage;

});