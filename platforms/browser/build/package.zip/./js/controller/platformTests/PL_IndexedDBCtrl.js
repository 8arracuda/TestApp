sdApp.controller('PL_IndexedDBCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PL';

});