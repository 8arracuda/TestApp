sdApp.controller('PL_PGSQLiteCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PL';

});