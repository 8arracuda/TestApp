sdApp.controller('PL_WebSqlCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PL';

});