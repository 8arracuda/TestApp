sdApp.controller('PL_SessionStorageCtrl', function ($scope, $rootScope) {

    $rootScope.section = 'PL';

});