sdApp.controller('SessionStorageCtrl', function ($scope) {

    $rootScope.section = 'PL';

});