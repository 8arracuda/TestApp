sdApp.controller('DE_PGSQLiteMediendatenCtrl', function ($scope) {



});