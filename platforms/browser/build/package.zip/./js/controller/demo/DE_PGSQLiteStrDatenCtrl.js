sdApp.controller('DE_PGSQLiteStrDatenCtrl', function ($scope, $rootScope) {



});