

sdApp.controller('DE_SessionStorageEinzelwerteCtrl', function ($scope, $rootScope) {


    $scope.myTestFunction = function() {
        alert('myTest');
    }

});