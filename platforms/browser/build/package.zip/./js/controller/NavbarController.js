sdApp.controller('NavbarController', function ($scope) {

});